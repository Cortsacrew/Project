class AmazonPrime extends StreamingService{
    
  private String name;
  private double subscription;
  
  @Override
  public void prompt(){
    System.out.println("Thank you for choosing AmazonPrime! Here are our top shows!");
  }
  
  public void setName(String name){
    this.name = name;
  }
  public String getName(String name){
    return this.name; 
  }

  public void setSubscription(double subscription){
    this.subscription = subscription;
  }

  public double getsubscription(){
    return this.subscription;
  }
    
  public String toString(){
    return (name + " will cost " + subscription + " per month. Includes free shipping!");
  }

  public AmazonPrime(String addOn, double cost){
    this.addOn = addOn;
    this.cost = cost;
  }

  public void extras(){
    System.out.println("You may add " + this.addOn + " for an aditional " + this.cost + " per month ");
  }
  
}  
