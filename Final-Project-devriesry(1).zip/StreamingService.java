abstract class StreamingService{
  public String addOn;
  public double cost;
  public int devices;
  public int subLength;
  public String sports;
  abstract void prompt();
}

