class Netflix extends StreamingService{

  private String name;
  private double subscription;

  @Override
  public void prompt(){
    System.out.println("Thank you for choosing Netflix! Here is a list of some amazing shows!");
  }

  public void setName(String name){
    this.name = name;
  }
  public String getName(String name){
    return this.name; 
  }

  public void setSubscription(double subscription){
    this.subscription = subscription;
  }

  public double getsubscription(){
    return this.subscription;
  }
    
  public String toString(){
    return (name + " will cost " + subscription + " per month. Enjoy their original shows!");
  }

  public Netflix (int subLength, int devices){
    this.subLength = subLength;
    this.devices = devices;
  }
  public void newSubscriber(){
    System.out.println("Your subscription will last " + this.subLength + " months and will be available on " + this.devices + " Devices");
  }
  
}  